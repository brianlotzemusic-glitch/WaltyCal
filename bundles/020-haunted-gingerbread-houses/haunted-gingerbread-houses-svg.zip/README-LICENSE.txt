HAUNTED GINGERBREAD HOUSES - 6 SVG CUT FILES
by Duskwood Designs Co (etsy.com/shop/DuskwoodDesignsCo)
Thank you for your purchase!

DESIGNS
  Standing pieces:  01 Crooked Haunted Gingerbread House
                    02 Gingerbread Manor with Witch-Hat Tower
                    03 Spiderweb Gingerbread House
                    05 Skull-Topped Gingerbread House
  Wide panel:       04 Haunted Gingerbread Village
  Ornament:         06 Haunted Gingerbread Ornament

FILES
  SVG/  Cricut Design Space, Silhouette Designer Edition, Inkscape, Illustrator
  DXF/  Silhouette Studio Basic Edition, laser/CNC software (inches)
  PNG/  transparent background, 1800 px on the longest side (6 in at 300 DPI)

Each design is a single-layer shape with one clean cut path. Windows,
doors, piped icing, the spider web and the pumpkin face are cut-outs; the
bats, moon, chimney smoke and dangling spider are attached, so nothing
falls out. Default size is 6 inches on the longest side; resize freely,
but keep the proportions locked.

SIZING TIPS
  Standing pieces (01, 02, 03, 05): each sits on a flat base strip, so it
  stands up on its own when cut from 3 mm wood or acrylic, or from heavy
  cardstock (glue two layers together for extra stiffness). We recommend
  5 in tall or larger in wood or acrylic and 4 in or larger in cardstock.
  Panel (04): use it as a window decal, light-box or shadow-box front, or a
  mantel silhouette. It has small windows, so we recommend 10 in wide or
  larger for vinyl and cardstock and 12 in or larger for laser-cut wood.
  Ornament (06): cut from cardstock, wood or acrylic at 4 in or larger and
  hang it from the loop at the top.
  The narrowest material is about 0.08 in at 6 in. Do a test cut first on
  a new material. Put a battery tea light behind any of them for a glow.

LICENSE
  Personal use: unlimited.
  Small-business commercial use: you may sell finished physical products
  (ornaments, decals, signs, shirts, cards, etc.) made with these designs,
  up to 500 units per design.
  You may NOT resell, share or redistribute the digital files themselves,
  in original or modified form, or include them in other digital products.
