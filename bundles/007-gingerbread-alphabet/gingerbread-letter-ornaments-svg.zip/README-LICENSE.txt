GINGERBREAD LETTER ORNAMENTS - FULL A-Z ALPHABET, 26 SVG CUT FILES
by Duskwood Designs Co (etsy.com/shop/DuskwoodDesignsCo)
Thank you for your purchase!

DESIGNS
  26 gingerbread-cookie letter ornaments, A to Z (01-letter-a ... 26-letter-z).
  Each letter has piped-icing cut-outs and a hanging loop built in.
  Cut one letter per ornament, or cut several to spell a name.

FILES
  SVG/  Cricut Design Space, Silhouette Designer Edition, Inkscape, Illustrator
  DXF/  Silhouette Studio Basic Edition, laser/CNC software (inches)
  PNG/  1800 x 1800 px, transparent background (6 in at 300 DPI)

Each letter is a single-layer shape with one clean cut path, including the
hanging loop at the top. Resize freely, but keep the proportions locked.

SIZING TIPS
  Every letter is drawn at the same height, with the same cap height and
  baseline. To spell a name, give every letter the SAME HEIGHT (not the same
  width) and the letters will line up; wide letters like M and W are simply
  wider. At the default size each letter is about 5.8 in tall including the
  hanging loop.
  Popular sizes: 3 to 4 in tall for tree ornaments and gift tags, 5 to 6 in
  for door or wall letters. The icing lines are about 0.13 in wide at 5.8 in;
  we recommend 3 in or taller for cardstock and vinyl, and 3.5 in or taller
  for laser-cut wood or acrylic. Do a test cut first on a new material.

LICENSE
  Personal use: unlimited.
  Small-business commercial use: you may sell finished physical products
  (ornaments, gift tags, cards, decals, shirts, etc.) made with these
  designs, up to 500 units per design.
  You may NOT resell, share or redistribute the digital files themselves,
  in original or modified form, or include them in other digital products.
