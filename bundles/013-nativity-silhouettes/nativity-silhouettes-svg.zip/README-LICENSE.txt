NATIVITY SILHOUETTES - 6 SVG CUT FILES
by Duskwood Designs Co (etsy.com/shop/DuskwoodDesignsCo)
Thank you for your purchase!

DESIGNS
  01 Holy Family in the Stable
  02 Manger Under the Star
  03 Three Magi on Camels (wide panel)
  04 The Good Shepherd
  05 Star of Bethlehem
  06 Herald Angel

FILES
  SVG/  Cricut Design Space, Silhouette Designer Edition, Inkscape, Illustrator
  DXF/  Silhouette Studio Basic Edition, laser/CNC software (inches)
  PNG/  transparent background, 1800 px on the longest side (6 in at 300 DPI)

Each design is a single-layer shape with one clean cut path, so no slicing,
welding or cleanup is needed. Stars, figures and animals are all attached,
so nothing falls out. Default size is 6 in on the longest side; resize
freely, but keep the proportions locked.

SIZING TIPS
  Vinyl (windows, glass blocks, mugs, signs): 4 in or larger.
  Cardstock (cards, ornaments, mantel scenes): 5 in or larger.
  Laser-cut wood or acrylic: 5 in or larger in 3 mm material. The scenes
  with a flat ground strip (01, 02, 04, 05, 06) stand up on their own when
  set in a slotted base.
  Heat-transfer vinyl (shirts, totes, pillows): 5 in or larger.
  The wide Three Magi panel (03) works best at 8 in wide or larger.
  The narrowest material and the narrowest gap are both about 0.08 in at
  6 in. Do a test cut first on a new material.

LICENSE
  Personal use: unlimited.
  Small-business commercial use: you may sell finished physical products
  (ornaments, cards, decals, signs, shirts, etc.) made with these designs,
  up to 500 units per design.
  You may NOT resell, share or redistribute the digital files themselves,
  in original or modified form, or include them in other digital products.
