CHRISTMAS VILLAGE SILHOUETTES - 6 SVG CUT FILES
by Duskwood Designs Co (etsy.com/shop/DuskwoodDesignsCo)
Thank you for your purchase!

DESIGNS
  Wide panels:      01 Village Street Skyline
                    02 Moonlit Cottages Light Box
  Standing pieces:  03 Cottage with Smoking Chimney
                    04 Starlit Chapel
                    05 Gingerbread House
                    06 Cabin Among Pines

FILES
  SVG/  Cricut Design Space, Silhouette Designer Edition, Inkscape, Illustrator
  DXF/  Silhouette Studio Basic Edition, laser/CNC software (inches)
  PNG/  transparent background, 1800 px on the longest side (6 in at 300 DPI)

Each design is a single-layer shape with one clean cut path. Windows, doors,
snowflakes and icing lines are cut-outs; smoke, stars and the chapel bell
are attached, so nothing falls out. Default size is 6 inches on the longest
side; resize freely, but keep the proportions locked.

SIZING TIPS
  Panels (01, 02): use them as window decals, light-box fronts, mantel or
  shelf silhouettes. The windows and snow dots are small at 6 in, so we
  recommend 10 in wide or larger for vinyl and cardstock and 12 in or larger
  for laser-cut wood. For a light box, back the panel with vellum or
  tracing paper and put a battery tea light or LED strip behind it.
  Standing pieces (03-06): each sits on a flat base strip, so it stands up
  on its own when cut from 3 mm wood or acrylic, or from heavy cardstock
  (glue two layers together for extra stiffness). We recommend 5 in tall or
  larger in wood or acrylic and 4 in or larger in cardstock. Line them up
  on a shelf or mantel to build a little village.
  The narrowest material is about 0.07 in at 6 in. Do a test cut first on a
  new material.

LICENSE
  Personal use: unlimited.
  Small-business commercial use: you may sell finished physical products
  (ornaments, gift tags, cards, decals, shirts, etc.) made with these
  designs, up to 500 units per design.
  You may NOT resell, share or redistribute the digital files themselves,
  in original or modified form, or include them in other digital products.
