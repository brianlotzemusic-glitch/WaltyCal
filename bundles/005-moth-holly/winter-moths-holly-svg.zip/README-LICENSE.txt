WINTER MOTHS & HOLLY - 6 SVG CUT FILES
Thank you for your purchase!

DESIGNS
  01 Snowflake Moth     02 Luna Moon Moth       03 Holly Wreath Moth
  04 Moth Over Star     05 Holly & Moon Corner  06 Moth Ornament

FILES
  SVG/  Cricut Design Space, Silhouette Designer Edition, Inkscape, Illustrator
  DXF/  Silhouette Studio Basic Edition, laser/CNC software
  PNG/  1800 x 1800 px, transparent background (6 in at 300 DPI)

Each design is a single-layer shape with one clean cut path. Default size
is 6 inches; resize freely. For the detailed designs (Moth Over Star,
Moth Ornament, Holly Wreath Moth) we recommend 5 inches or larger for vinyl
and 6 inches or larger for cardstock.

LICENSE
  Personal use: unlimited.
  Small-business commercial use: you may sell finished physical products
  (shirts, decals, ornaments, cards, etc.) made with these designs, up to
  500 units per design.
  You may NOT resell, share or redistribute the digital files themselves,
  in original or modified form, or include them in other digital products.
