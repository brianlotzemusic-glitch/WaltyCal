BAT CHRISTMAS - 6 SVG CUT FILES
Thank you for your purchase!

DESIGNS
  01 Bat Wing Tree     02 Santa Hat Bat     03 Candy Cane Bat
  04 Bat Garland       05 Holly Bat Wreath  06 Bat Wing Star

FILES
  SVG/  Cricut Design Space, Silhouette Designer Edition, Inkscape, Illustrator
  DXF/  Silhouette Studio Basic Edition, laser/CNC software
  PNG/  1800 x 1800 px, transparent background (6 in at 300 DPI)

Each design is a single-layer shape with one clean cut path. Default size
is 6 inches on the longest side; resize freely. The Bat Garland is a
repeatable strip: cut several and line up the end stars to make a longer
garland. The Bat Wing Star has a slotted tab to slip over a tree branch
(cut it from sturdy cardstock or felt). For vinyl we recommend 4 inches
or larger; for cardstock 5 inches or larger.

LICENSE
  Personal use: unlimited.
  Small-business commercial use: you may sell finished physical products
  (shirts, decals, ornaments, cards, etc.) made with these designs, up to
  500 units per design.
  You may NOT resell, share or redistribute the digital files themselves,
  in original or modified form, or include them in other digital products.
