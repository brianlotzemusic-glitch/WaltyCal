BOTANICAL FROST SNOWFLAKES - 6 SVG CUT FILES
by Duskwood Designs Co (etsy.com/shop/DuskwoodDesignsCo)
Thank you for your purchase!

DESIGNS
  01 Pine Bough Snowflake
  02 Fern Frond Snowflake
  03 Berry Sprig Snowflake
  04 Holly Crystal Snowflake
  05 Acorn & Oak Snowflake
  06 Frosted Twig Snowflake

FILES
  SVG/  Cricut Design Space, Silhouette Designer Edition, Inkscape, Illustrator
  DXF/  Silhouette Studio Basic Edition, laser/CNC software (inches)
  PNG/  transparent background, 1800 x 1800 px (6 in at 300 DPI)

Each design is a single-layer shape with one clean cut path, so no slicing,
welding or cleanup is needed. Leaves, berries, cones and acorns are all
attached, so nothing falls out. Default size is 6 x 6 inches; resize freely,
but keep the proportions locked.

SIZING TIPS
  Vinyl (windows, mugs, tumblers, glass blocks): 3 in or larger.
  Cardstock (ornaments, gift tags, cards, garlands): 4 in or larger.
  Laser-cut wood or acrylic ornaments: 3.5 in or larger in 3 mm material.
  Heat-transfer vinyl (shirts, totes, pillows): 4 in or larger.
  The narrowest material is about 0.08 in at 6 in. Do a test cut first on a
  new material, and use a fresh blade for the leaf tips.

LICENSE
  Personal use: unlimited.
  Small-business commercial use: you may sell finished physical products
  (ornaments, gift tags, cards, decals, shirts, etc.) made with these
  designs, up to 500 units per design.
  You may NOT resell, share or redistribute the digital files themselves,
  in original or modified form, or include them in other digital products.
