GOTHIC CHRISTMAS ORNAMENTS - 6 SVG CUT FILES
Thank you for your purchase!

DESIGNS
  01 Moon & Bat Bauble      04 Gothic Window Drop
  02 Spiderweb Bauble       05 Bat Wing Bauble
  03 Coffin Ornament        06 Rose Window Ornament

FILES
  SVG/  Cricut Design Space, Silhouette Designer Edition, Inkscape, Illustrator
  DXF/  Silhouette Studio Basic Edition, laser/CNC software (inches)
  PNG/  1800 x 1800 px, transparent background (6 in at 300 DPI)

Each design is a single-layer shape with one clean cut path, including the
hanging loop at the top. Default size is 6 inches; resize freely. For the
finer designs (Spiderweb, Coffin, Rose Window) we recommend 4 inches or larger
for vinyl and 5 inches or larger for cardstock, felt or wood.

LICENSE
  Personal use: unlimited.
  Small-business commercial use: you may sell finished physical products
  (ornaments, shirts, decals, cards, etc.) made with these designs, up to
  500 units per design.
  You may NOT resell, share or redistribute the digital files themselves,
  in original or modified form, or include them in other digital products.
