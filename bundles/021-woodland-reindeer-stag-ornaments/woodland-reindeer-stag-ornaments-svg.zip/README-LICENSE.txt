WOODLAND REINDEER & STAG ORNAMENTS - 6 SVG CUT FILES
by Duskwood Designs Co (etsy.com/shop/DuskwoodDesignsCo)
Thank you for your purchase!

DESIGNS
  01 Stag Head Ornament (front-facing stag with holly)
  02 Leaping Reindeer Ornament (moon, star and snowy pines)
  03 Woodland Stag Ornament (stag in a pine wood under a crescent moon)
  04 Reindeer with Scarf Ornament (shaped ornament on a snowy base)
  05 Stag Bauble Ornament (classic bauble with a stag cut out of it)
  06 Reindeer Pair Ornament (two reindeer under a star, scalloped frame)

FILES
  SVG/  Cricut Design Space, Silhouette Designer Edition, Inkscape, Illustrator
  DXF/  Silhouette Studio Basic Edition, laser/CNC software (inches)
  PNG/  transparent background, 1800 px on the longest side (6 in at 300 DPI)

Each design is a single-layer shape with one clean cut path and a hanging
loop or hole built in. Stars, moons and trees are attached, so nothing
falls out. Default size is about 6 inches on the longest side; resize
freely, but keep the proportions locked.

SIZING TIPS
  Cardstock, glitter card, felt or vinyl: 4 in or larger.
  Laser-cut wood or acrylic (3 mm or thinner): 4.5 in or larger.
  The thinnest parts (antler tines and legs) are about 0.08 in wide at
  6 in, so do not go below 4 in, and do a test cut on a new material first.
  04 stands on its snowy base when cut from 3 mm wood or acrylic, or hang
  it by the hole in its back.

LICENSE
  Personal use: unlimited.
  Small-business commercial use: you may sell finished physical products
  (ornaments, decals, signs, shirts, cards, etc.) made with these designs,
  up to 500 units per design.
  You may NOT resell, share or redistribute the digital files themselves,
  in original or modified form, or include them in other digital products.
