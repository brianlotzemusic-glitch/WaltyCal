FILIGREE CHRISTMAS ORNAMENTS - 6 SVG CUT FILES
by Duskwood Designs Co (etsy.com/shop/DuskwoodDesignsCo)
Thank you for your purchase!

DESIGNS
  01 Snowflake Lace Bauble    04 Fir Branch Tree
  02 Holly Filigree Bell      05 Scrollwork Drop
  03 Fern Lace Star           06 Filigree Pinecone

FILES
  SVG/  Cricut Design Space, Silhouette Designer Edition, Inkscape, Illustrator
  DXF/  Silhouette Studio Basic Edition, laser/CNC software (inches)
  PNG/  1800 x 1800 px, transparent background (6 in at 300 DPI)

Each design is a single-layer shape with one clean cut path, including the
hanging loop at the top. Default size is 6 inches; resize freely (keep the
proportions locked). These are lacy, openwork designs: at 6 inches the main
lines are about 0.08 to 0.12 inch wide. We recommend 4 inches or larger for
vinyl, 5 inches or larger for cardstock and laser-cut wood, and the full
6 inches for acrylic, which is more brittle. The finest details are in the
Fir Branch Tree, Fern Lace Star and Scrollwork Drop; do a test cut first on
a new material.

LICENSE
  Personal use: unlimited.
  Small-business commercial use: you may sell finished physical products
  (ornaments, gift tags, cards, decals, shirts, etc.) made with these
  designs, up to 500 units per design.
  You may NOT resell, share or redistribute the digital files themselves,
  in original or modified form, or include them in other digital products.
